"use strict";
/* Wave Android — ТЗ 3.1.2: проверка обновлений.
   Раз в сутки (флаг wave.updAt в localStorage) страница канала t.me/s/wavesound_app забирается
   через локальный прокси /px/ (мост bridge.js, CSP пропускает только https и same-origin),
   из постов вычленяется последняя версия 4.x, сравнивается с S.version; если новее — ненавязчивая
   плашка «Обновить» / «Позже», сама исчезает через минуту. «Обновить» открывает пост с версией
   в Telegram (NATIVE.openUrl, только https). Без сети или без версии в канале — молча.
   Ручная проверка — строка «Проверить обновления» в карточке «О программе» (report.js). */
(() => {
  const root = document.documentElement;
  if (!root.hasAttribute("data-mobile")) return;

  const NATIVE = window.WaveAndroid || null;
  const CHANNEL = "wavesound_app";
  const SITE = "https://t.me/s/" + CHANNEL;
  const DAY = 24 * 60 * 60 * 1000;

  const verArr = (v) =>
    String(v || "")
      .trim()
      .replace(/-.*$/, "")
      .split(".")
      .map((n) => parseInt(n, 10) || 0);
  function cmpVer(a, b) {
    const A = verArr(a),
      B = verArr(b);
    for (let i = 0; i < Math.max(A.length, B.length); i++) {
      const x = A[i] || 0,
        y = B[i] || 0;
      if (x !== y) return x < y ? -1 : 1;
    }
    return 0;
  }

  /* последняя версия 4.x из HTML-превью канала (DOMParser) → { version, post } или null */
  function parse(html) {
    try {
      const doc = new DOMParser().parseFromString(html, "text/html");
      let best = null;
      for (const msg of doc.querySelectorAll(".tgme_widget_message[data-post]")) {
        const post = (msg.getAttribute("data-post") || "").split("/").pop();
        const text = msg.querySelector(".tgme_widget_message_text")?.textContent || "";
        for (const m of text.matchAll(/\b4\.\d{1,2}(?:\.\d{1,2})?\b/g)) {
          const v = m[0];
          if (!best || cmpVer(v, best.version) > 0) best = { version: v, post: post || "" };
        }
      }
      return best;
    } catch {
      return null;
    }
  }

  let el = null,
    hideT = 0;
  function show(version, link) {
    hide();
    el = document.createElement("div");
    el.className = "upd";
    el.id = "update";
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-label", "Доступно обновление");
    el.innerHTML =
      `<div class="upd-card">` +
      `<div class="upd-txt"><b>Доступна Wave ${esc(version)}</b><small>Опубликована в Telegram-канале Wave</small></div>` +
      `<button class="upd-btn" data-upd-open>Обновить</button>` +
      `<button class="upd-x" data-upd-later aria-label="Позже"><svg viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>` +
      `</div>`;
    document.body.appendChild(el);
    el.addEventListener("click", (e) => {
      if (e.target.closest("[data-upd-open]")) {
        if (NATIVE && typeof NATIVE.openUrl === "function") NATIVE.openUrl(link);
        else window.open(link, "_blank");
        hide();
      } else if (e.target.closest("[data-upd-later]")) hide();
    });
    hideT = setTimeout(hide, 60000); /* не мешать работе: сама исчезает */
  }
  function hide() {
    clearTimeout(hideT);
    if (!el) return;
    const x = el;
    el = null;
    x.classList.add("out");
    setTimeout(() => x.remove(), 280);
  }

  let busy = false;
  async function check(manual) {
    if (busy) return;
    busy = true;
    try {
      if (!manual) {
        let last = 0;
        try {
          last = +localStorage.getItem("wave.updAt") || 0;
        } catch {}
        if (Date.now() - last < DAY) return;
      }
      try {
        localStorage.setItem("wave.updAt", String(Date.now()));
      } catch {}
      if (navigator.onLine === false) {
        if (manual) toast("Нет сети");
        return;
      }
      /* страница канала забирается ядром (команда "updates"): медиа-прокси /px/ отдаёт только CDN */
      const r = await api("updates");
      const found = parse((r && r.html) || "");
      const cur = S.version || "";
      if (!found) {
        if (manual) toast("В канале пока не найдена версия");
        return;
      }
      if (cmpVer(found.version, cur) <= 0) {
        if (manual) toast("У вас последняя версия" + (cur ? " (" + cur + ")" : ""));
        return;
      }
      show(found.version, found.post ? `https://t.me/${CHANNEL}/${found.post}` : `https://t.me/${CHANNEL}`);
    } catch (e) {
      if (manual) toast("Не удалось проверить обновления" + (e && e.message ? ": " + e.message : ""));
    } finally {
      busy = false;
    }
  }
  window.waveUpd = { check, show, parse };

  /* при запуске — когда сплэш уйдёт и пара секунд простоя; не чаще раза в сутки */
  new Promise((res) => {
    let n = 0;
    const t = setInterval(() => {
      if (++n > 120) {
        clearInterval(t);
        res();
        return;
      }
      const sp = document.getElementById("splash");
      if ((!sp || sp.classList.contains("out")) && n > 8) {
        clearInterval(t);
        setTimeout(res, 2500);
      }
    }, 250);
  }).then(() => check(false));
})();
