/* wave-profile (4.20.3): a small rectangular profile banner with a shape choice, an avatar editor (size, zoom,
   position), live (animated) pictures, and a side swipe that closes the full player. Loaded after wave-extra.js. */
(() => {
  "use strict";
  if (typeof S === "undefined" || typeof BL_DEF === "undefined") return;
  const $q = (s, r = document) => r.querySelector(s);
  const isMob = () => document.documentElement.hasAttribute("data-mobile");
  const clamp = (v, a, b) => Math.max(a, Math.min(b, Number.isFinite(+v) ? +v : a));
  const prof = () => (S.settings && S.settings.profile) || {};
  const refresh = () => { if (S.route === "profile" || S.route === "settings") reroute(); };

  /* ---------- defaults ---------- */
  BL_DEF.ratio = 3; // the banner on the phone: a 3:1 rectangle
  const RATIOS = [[4, "4:1"], [3, "3:1"], [2.5, "5:2"], [2, "2:1"]];
  const AV_DEF = { zoom: 100, x: 50, y: 50, size: 1, r: 0 };
  const AV_SIZES = [[0.8, "Маленький"], [1, "Обычный"], [1.25, "Большой"]];
  const LIM = { height: [140, 600, 10, "Высота"], zoom: [100, 400, 5, "Масштаб"], x: [0, 100, 1, "По горизонтали"], y: [0, 100, 1, "По вертикали"] };
  const avLayout = () => ({ ...AV_DEF, ...(prof().avatarLayout || {}) });
  const imgRatio = (u) => new Promise((ok) => {
    if (!u) return ok(1);
    const im = new Image(), tm = setTimeout(() => ok(1), 5000);
    im.onload = () => { clearTimeout(tm); ok(im.naturalWidth && im.naturalHeight ? im.naturalWidth / im.naturalHeight : 1); };
    im.onerror = () => { clearTimeout(tm); ok(1); };
    im.src = u;
  });
  // the size of a picture that covers a w×h box, times the zoom → how far it can move
  const moveRange = (w, h, r, z) => {
    r = r || w / h;
    const cw = Math.max(w, h * r) * z, ch = Math.max(h, w / r) * z;
    return [Math.max(40, cw - w), Math.max(30, ch - h)];
  };
  function avCss(L) {
    const z = clamp(L.zoom, 100, 400);
    const size = !L.r ? (z === 100 ? "cover" : `${z}% auto`) : L.r >= 1 ? `auto ${z}%` : `${z}% auto`;
    return `background-size:${size};background-position:${clamp(L.x, 0, 100)}% ${clamp(L.y, 0, 100)}%;background-repeat:no-repeat`;
  }
  function syncRoot() {
    const p = prof(), st = document.documentElement.style;
    const bl = { ...BL_DEF, ...(p.bannerLayout || {}) };
    st.setProperty("--pb-ratio", String(clamp(bl.ratio || 3, 1.5, 5)));
    st.setProperty("--av-k", String(clamp(avLayout().size || 1, 0.6, 1.5)));
  }

  /* ---------- the avatar with its own zoom / position ---------- */
  window.avatarHtml = function (cls, id = "") {
    const p = prof();
    const src = p.avatar ? (typeof thumb === "function" ? thumb(p.avatar, "m") : p.avatar) : "";
    const st = src ? ` style="background-image:url('${esc(src)}');${avCss(avLayout())}"` : "";
    return `<span class="avatar ${cls}"${id ? ` id="${id}"` : ""}${st}>${p.avatar ? "" : esc((p.nick || "W")[0].toUpperCase())}</span>`;
  };
  const origApply = window.applySettings;
  if (typeof origApply === "function")
    window.applySettings = function (...a) {
      const r = origApply.apply(this, a);
      try { syncRoot(); } catch {}
      return r;
    };
  syncRoot();

  /* ---------- drag with a finger / mouse, two fingers or the wheel = zoom ---------- */
  function gestures(stage, L, draw, range) {
    stage.style.touchAction = "none";
    const pts = new Map();
    let pinch = null;
    stage.addEventListener("pointerdown", (e) => {
      stage.setPointerCapture?.(e.pointerId);
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 2) {
        const [a, b] = [...pts.values()];
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, z: L.zoom };
      }
      e.preventDefault();
    });
    stage.addEventListener("pointermove", (e) => {
      const p = pts.get(e.pointerId);
      if (!p) return;
      if (pts.size >= 2 && pinch) {
        p.x = e.clientX; p.y = e.clientY;
        const [a, b] = [...pts.values()];
        L.zoom = clamp(Math.round(pinch.z * (Math.hypot(a.x - b.x, a.y - b.y) / pinch.d)), 100, 400);
        return draw();
      }
      const [rx, ry] = range();
      L.x = clamp(L.x - ((e.clientX - p.x) / rx) * 100, 0, 100);
      L.y = clamp(L.y - ((e.clientY - p.y) / ry) * 100, 0, 100);
      p.x = e.clientX; p.y = e.clientY;
      draw();
    });
    const up = (e) => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; };
    stage.addEventListener("pointerup", up);
    stage.addEventListener("pointercancel", up);
    stage.addEventListener("wheel", (e) => { e.preventDefault(); L.zoom = clamp(L.zoom - Math.sign(e.deltaY) * 10, 100, 400); draw(); }, { passive: false });
  }
  const sliders = (pre, keys) => `<div class="be-grid">${keys.map((k) => `<label>${LIM[k][3]}<input type="range" id="${pre}-${k}" min="${LIM[k][0]}" max="${LIM[k][1]}" step="${LIM[k][2]}"><b id="${pre}-${k}-v"></b></label>`).join("")}</div>`;
  const segs = (id, list) => `<div class="seg wp-seg" id="${id}">${list.map(([v, l]) => `<button type="button" data-v="${v}">${l}</button>`).join("")}</div>`;
  const hint = () => isMob() ? "Двигайте пальцем, двумя пальцами — масштаб." : "Перетащите мышью, колесо — масштаб.";

  /* ---------- banner editor ---------- */
  window.bannerEditor = async function () {
    let p = prof();
    if (!p.banner) {
      if (!(await pickProfileImage("banner"))) return;
      refresh();
      p = prof();
    }
    const L = bannerLayout();
    L.ratio = clamp(L.ratio || 3, 1.5, 5);
    const mob = isMob();
    const keys = mob ? ["zoom", "x", "y"] : ["height", "zoom", "x", "y"];
    const cw = Math.max(600, $q("#content")?.clientWidth || 1000);
    dialog(
      `<h3>Баннер профиля</h3><p class="muted wp-hint">${hint()} Подходят обычные фото и живые картинки (GIF, анимированные WebP/PNG до 6 МБ).</p>
      <div class="be-stage wp-bstage" id="be-stage">${bannerImg(p.banner, L)}</div>
      ${mob ? `<div class="wp-row"><span>Форма</span>${segs("be-ratio", RATIOS)}</div>` : ""}
      ${sliders("be", keys)}
      <div class="acts wp-acts"><button class="btn ghost" id="be-pick">Другая картинка</button><button class="btn ghost" id="be-rm">Убрать</button><span style="flex:1"></span><button class="btn ghost" id="be-reset">Сбросить</button><button class="btn" data-close>Отмена</button><button class="btn acc" id="be-save">Сохранить</button></div>`,
      (d) => {
        d.classList.add("wide");
        const stage = d.querySelector("#be-stage"), img = stage.querySelector("img");
        const draw = () => {
          if (mob) { stage.style.height = ""; stage.style.aspectRatio = `${L.ratio} / 1`; }
          else { stage.style.aspectRatio = ""; stage.style.height = Math.round(((stage.clientWidth || 640) * L.height) / cw) + "px"; }
          img.style.objectPosition = `${L.x}% ${L.y}%`;
          img.style.transformOrigin = `${L.x}% ${L.y}%`;
          img.style.transform = `scale(${L.zoom / 100})`;
          for (const k of keys) {
            d.querySelector("#be-" + k).value = L[k];
            d.querySelector("#be-" + k + "-v").textContent = k === "height" ? L[k] + " px" : Math.round(L[k]) + "%";
          }
          d.querySelectorAll("#be-ratio button").forEach((b) => b.classList.toggle("on", +b.dataset.v === +L.ratio));
        };
        for (const k of keys) d.querySelector("#be-" + k).oninput = (e) => { L[k] = +e.target.value; draw(); };
        d.querySelectorAll("#be-ratio button").forEach((b) => (b.onclick = () => { L.ratio = +b.dataset.v; draw(); }));
        gestures(stage, L, draw, () => moveRange(stage.clientWidth || 300, stage.clientHeight || 100, img.naturalWidth / img.naturalHeight, L.zoom / 100));
        d.querySelector("#be-reset").onclick = () => { Object.assign(L, BL_DEF); draw(); };
        d.querySelector("#be-pick").onclick = async () => {
          d.close();
          if (await pickProfileImage("banner")) { refresh(); window.bannerEditor(); }
        };
        d.querySelector("#be-rm").onclick = async () => {
          d.close();
          try { S.settings = await api("settings", { profile: { banner: null } }); } catch (e) { return toast(e.message); }
          applySettings();
          refresh();
        };
        d.querySelector("#be-save").onclick = async () => {
          try { S.settings = await api("settings", { profile: { bannerLayout: { ...L } } }); } catch (e) { return toast(e.message); }
          d.close();
          applySettings();
          refresh();
        };
        requestAnimationFrame(draw);
        img.onload = draw;
      },
    );
  };

  /* ---------- avatar editor ---------- */
  let pickingFromEditor = false;
  async function avatarEditor() {
    let p = prof();
    if (!p.avatar) {
      pickingFromEditor = true;
      try { if (!(await pickProfileImage("avatar"))) return; } finally { pickingFromEditor = false; }
      refresh();
      p = prof();
    }
    const L = avLayout();
    if (!L.r) L.r = await imgRatio(p.avatar);
    dialog(
      `<h3>Аватар</h3><p class="muted wp-hint">${hint()} В кружке — то, что увидят все.</p>
      <div class="wp-avwrap"><div class="wp-avstage" id="av-stage" style="background-image:url('${esc(p.avatar)}')"></div></div>
      <div class="wp-row"><span>Размер в профиле</span>${segs("av-size", AV_SIZES)}</div>
      ${sliders("av", ["zoom", "x", "y"])}
      <div class="acts wp-acts"><button class="btn ghost" id="av-pick">Другое фото</button><button class="btn ghost" id="av-rm">Убрать</button><span style="flex:1"></span><button class="btn ghost" id="av-reset">Сбросить</button><button class="btn" data-close>Отмена</button><button class="btn acc" id="av-save">Сохранить</button></div>`,
      (d) => {
        const stage = d.querySelector("#av-stage");
        const draw = () => {
          const px = Math.round(180 * clamp(L.size, 0.6, 1.5));
          stage.style.width = stage.style.height = px + "px";
          const css = avCss(L).split(";");
          for (const c of css) { const [k, v] = c.split(":"); if (k && v) stage.style.setProperty(k, v); }
          for (const k of ["zoom", "x", "y"]) {
            d.querySelector("#av-" + k).value = L[k];
            d.querySelector("#av-" + k + "-v").textContent = Math.round(L[k]) + "%";
          }
          d.querySelectorAll("#av-size button").forEach((b) => b.classList.toggle("on", +b.dataset.v === +L.size));
        };
        for (const k of ["zoom", "x", "y"]) d.querySelector("#av-" + k).oninput = (e) => { L[k] = +e.target.value; draw(); };
        d.querySelectorAll("#av-size button").forEach((b) => (b.onclick = () => { L.size = +b.dataset.v; draw(); }));
        gestures(stage, L, draw, () => { const w = stage.clientWidth || 180; return moveRange(w, w, L.r, L.zoom / 100); });
        d.querySelector("#av-reset").onclick = () => { Object.assign(L, { ...AV_DEF, r: L.r }); draw(); };
        d.querySelector("#av-pick").onclick = async () => {
          d.close();
          pickingFromEditor = true;
          let u;
          try { u = await pickProfileImage("avatar"); } finally { pickingFromEditor = false; }
          if (u) { refresh(); avatarEditor(); }
        };
        d.querySelector("#av-rm").onclick = async () => {
          d.close();
          try { S.settings = await api("settings", { profile: { avatar: null, avatarLayout: { ...AV_DEF, size: L.size } } }); } catch (e) { return toast(e.message); }
          applySettings();
          refresh();
        };
        d.querySelector("#av-save").onclick = async () => {
          try { S.settings = await api("settings", { profile: { avatarLayout: { ...L } } }); } catch (e) { return toast(e.message); }
          d.close();
          applySettings();
          refresh();
        };
        requestAnimationFrame(draw);
      },
    );
  }
  window.avatarEditor = avatarEditor;

  /* ---------- after a new picture is picked: the editor opens right away ---------- */
  const origPick = window.pickProfileImage;
  if (typeof origPick === "function")
    window.pickProfileImage = async function (kind, ...rest) {
      const keepRatio = kind === "banner" ? clamp(prof().bannerLayout?.ratio || BL_DEF.ratio, 1.5, 5) : 0;
      const u = await origPick.call(this, kind, ...rest);
      if (!u) return u;
      try {
        if (kind === "banner" && keepRatio !== BL_DEF.ratio) {
          const bl = { ...BL_DEF, ratio: keepRatio };
          S.settings.profile.bannerLayout = bl;
          await api("settings", { profile: { bannerLayout: bl } });
        }
        if (kind === "avatar") {
          const al = { ...AV_DEF, size: avLayout().size, r: await imgRatio(u) };
          S.settings.profile.avatarLayout = al;
          await api("settings", { profile: { avatarLayout: al } });
          applySettings();
          if (!pickingFromEditor) setTimeout(() => avatarEditor(), 80);
        }
      } catch {}
      return u;
    };

  // a tap on your avatar / banner (when there is one) opens its editor; «Другое фото» is inside
  document.addEventListener(
    "click",
    (e) => {
      const t = e.target;
      if (!(t instanceof Element)) return;
      const p = prof();
      if (p.avatar && t.closest("#content > .phead > .avatar.pick, .content > .phead > .avatar.pick, #pick-avatar")) {
        e.preventDefault(); e.stopImmediatePropagation();
        return avatarEditor();
      }
      if (p.banner && isMob() && !t.closest(".pb-edit") && t.closest(".content > .pbanner.has") && !t.closest(".soc-original-profile")) {
        e.preventDefault(); e.stopImmediatePropagation();
        return window.bannerEditor();
      }
    },
    true,
  );

  /* ---------- a side swipe closes the full player (like the Android 17 back gesture) ---------- */
  (function sideSwipe() {
    let st = null;
    const fp = () => document.getElementById("fullplayer");
    const reset = (f) => { f.style.transition = ""; f.style.transform = ""; f.style.opacity = ""; };
    document.addEventListener("touchstart", (e) => {
      st = null;
      const f = fp();
      if (e.touches.length !== 1 || !f || f.hidden || !f.contains(e.target)) return;
      if (e.target.closest("input,textarea,[data-seek],[data-vol],#ly-text,.wx-grab,#lyrics,#tpanel,#dialog")) return;
      const x = e.touches[0].clientX;
      const edge = x < 72 || x > innerWidth - 72;
      if (!edge && e.target.closest(".fp-art,.fpa-cover")) return; // the cover keeps its own swipe (next / previous track)
      st = { x, y: e.touches[0].clientY, t: Date.now(), on: false, dx: 0 };
    }, { passive: true, capture: true });
    document.addEventListener("touchmove", (e) => {
      if (!st || e.touches.length !== 1) return;
      const f = fp();
      if (!f) return (st = null);
      const dx = e.touches[0].clientX - st.x, dy = e.touches[0].clientY - st.y;
      if (!st.on) {
        if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx)) return (st = null); // vertical — the swipe down handles it
        if (Math.abs(dx) < 14 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
        st.on = true;
        f.style.transition = "none";
      }
      if (e.cancelable) e.preventDefault();
      st.dx = dx;
      f.style.transform = `translateX(${dx}px)`;
      f.style.opacity = String(Math.max(0.4, 1 - Math.abs(dx) / (innerWidth * 1.2)));
    }, { passive: false, capture: true });
    const end = () => {
      if (!st) return;
      const d = st;
      st = null;
      const f = fp();
      if (!f || !d.on) return;
      const fast = Math.abs(d.dx) / Math.max(1, Date.now() - d.t) > 0.5;
      if (Math.abs(d.dx) > Math.min(120, innerWidth * 0.28) || (Math.abs(d.dx) > 50 && fast)) {
        f.style.transition = "transform .18s ease-out, opacity .18s ease-out";
        f.style.transform = `translateX(${d.dx > 0 ? innerWidth : -innerWidth}px)`;
        f.style.opacity = "0";
        const eat = (ev) => { ev.stopPropagation(); ev.preventDefault(); };
        document.addEventListener("click", eat, { capture: true, once: true });
        setTimeout(() => document.removeEventListener("click", eat, true), 400);
        setTimeout(() => { reset(f); if (typeof closeFull === "function") closeFull(true); }, 190);
      } else {
        f.style.transition = "transform .2s ease, opacity .2s ease";
        f.style.transform = "";
        f.style.opacity = "";
        setTimeout(() => reset(f), 220);
      }
    };
    document.addEventListener("touchend", end, { passive: true, capture: true });
    document.addEventListener("touchcancel", end, { passive: true, capture: true });
  })();
})();
