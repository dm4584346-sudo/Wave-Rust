//! extras.cjs + wave-recommendations.cjs: song keys, the merged search, the Wikipedia bio, Deezer similar artists,
//! and the relevance filter of «Моя волна».

use crate::http::{get_json, Opts};
use crate::js::{enc, qs, slice, J, R};
use crate::re;
use serde_json::{json, Map, Value};
use std::collections::HashSet;

/// lower case, ё → е, everything that is not a letter / digit removed
pub fn name_key(s: &str) -> String {
    let l = s.to_lowercase().replace('ё', "е");
    re!(r"[^\p{L}\p{N}]+").replace_all(&l, "").into_owned()
}
pub fn name_key_v(v: &Value) -> String {
    name_key(&v.s())
}
/// lower case, ё → е, non-word runs → one space, trimmed (main.cjs normName)
pub fn norm_name(s: &str) -> String {
    let l = s.to_lowercase().replace('ё', "е");
    re!(r"[^\p{L}\p{N}]+").replace_all(&l, " ").trim().to_string()
}

/// lower case, non-word runs → one space, trimmed (lyrics / Yandex «low»)
pub fn norm_words(s: &str) -> String {
    re!(r"[^\p{L}\p{N}]+").replace_all(&s.to_lowercase(), " ").trim().to_string()
}

fn first_artist_of(t: &Value) -> String {
    let n = t.g("artists").at(0).g("name");
    if n.truthy() {
        return n.s();
    }
    let a = t.g("artist").s();
    re!(r"(?i),|&| feat\.? | ft\.? ").split(&a).next().unwrap_or("").to_string()
}

/// «artist|title» without versions / feat.
pub fn song_key(t: &Value) -> String {
    if !t.truthy() {
        return String::new();
    }
    let a = first_artist_of(t);
    let title = t.g("title").s();
    let title = re!(r"\s*[(\[][^)\]]*[)\]]").replace_all(&title, "");
    let title = re!(r"(?i)\s+(feat|ft)\.?\s.*$").replacen(&title, 1, "");
    let title = re!(r"\s+-\s+.*$").replacen(&title, 1, "").into_owned();
    let tk = if title.is_empty() { t.g("title").s() } else { title };
    format!("{}|{}", name_key(&a), name_key(&tk))
}

pub fn fresh_only(list: &[Value], ids: &HashSet<String>, keys: &HashSet<String>) -> Vec<Value> {
    let mut out = vec![];
    let mut seen = keys.clone();
    for t in list {
        let id = t.g("id").s();
        if id.is_empty() || ids.contains(&id) {
            continue;
        }
        let k = song_key(t);
        if k != "|" && seen.contains(&k) {
            continue;
        }
        seen.insert(k);
        out.push(t.clone());
    }
    out
}

pub fn fewer_liked(list: Vec<Value>, ids: &HashSet<String>, keys: &HashSet<String>) -> Vec<Value> {
    let liked = |t: &Value| ids.contains(&t.g("id").s()) || keys.contains(&song_key(t));
    let other: Vec<Value> = list.iter().filter(|t| !liked(t)).cloned().collect();
    if other.is_empty() {
        return list.into_iter().take(1).collect();
    }
    let fav = list.iter().find(|t| liked(t)).cloned();
    let fav = match fav {
        Some(f) if crate::js::rand_f() < 0.5 => f,
        _ => return other,
    };
    let mut out = other;
    let at = (2 + (crate::js::rand_f() * 4.0).floor() as usize).min(out.len());
    out.insert(at, fav);
    out
}

pub fn uniq_tracks(list: &[Value]) -> Vec<Value> {
    let mut ids = HashSet::new();
    let mut keys = HashSet::new();
    let mut out = vec![];
    for t in list {
        let id = t.g("id").s();
        if id.is_empty() || ids.contains(&id) {
            continue;
        }
        let k = song_key(t);
        if k != "|" && keys.contains(&k) {
            continue;
        }
        ids.insert(id);
        keys.insert(k);
        out.push(t.clone());
    }
    out
}

pub fn interleave(lists: Vec<Vec<Value>>) -> Vec<Value> {
    let mut its: Vec<std::collections::VecDeque<Value>> = lists.into_iter().map(|l| l.into()).collect();
    let mut out = vec![];
    while its.iter().any(|l| !l.is_empty()) {
        for l in its.iter_mut() {
            if let Some(x) = l.pop_front() {
                out.push(x);
            }
        }
    }
    out
}

/// got: { ym, sc, au, yt, sp, scUsers, scLists, videos } → { best, misspell, artists, tracks, albums, podcasts, playlists, videos }
pub fn merge_search(q: &str, got: &Value) -> Value {
    let qk = name_key(q);
    let ym = got.g("ym");
    let arr = |k: &str| got.g(k).arr().to_vec();
    let ym_tracks = ym.g("tracks").arr().to_vec();
    let rel = |t: &Value| -> i32 {
        let a0 = t.g("artists").at(0).g("name");
        let ak = name_key(&if a0.truthy() { a0.s() } else { t.g("artist").s() });
        if !ak.is_empty()
            && (ak == qk
                || (ak.chars().count() > 2 && qk.contains(&ak))
                || (qk.chars().count() > 3 && ak.contains(&qk)))
        {
            return 2;
        }
        if qk.chars().count() > 2 && name_key(&t.g("title").s()).contains(&qk) {
            1
        } else {
            0
        }
    };
    let mut rest: Vec<(Value, i32, usize)> = interleave(vec![
        ym_tracks.iter().skip(6).cloned().collect(),
        arr("yt"),
        arr("sc"),
        arr("au"),
        arr("sp"),
    ])
    .into_iter()
    .enumerate()
    .map(|(i, t)| {
        let r = rel(&t);
        (t, r, i)
    })
    .collect();
    rest.sort_by(|a, b| b.1.cmp(&a.1).then(a.2.cmp(&b.2)));
    let mut all: Vec<Value> = ym_tracks.iter().take(6).cloned().collect();
    all.extend(rest.into_iter().map(|x| x.0));
    let tracks = uniq_tracks(&all);
    let mut artists: Vec<Value> = vec![];
    let mut ak = HashSet::new();
    for a in ym.g("artists").arr().iter().chain(got.g("scUsers").arr().iter()) {
        let k = name_key(&a.g("name").s());
        if !a.truthy() || !a.g("name").truthy() || ak.contains(&k) {
            continue;
        }
        ak.insert(k);
        artists.push(a.clone());
    }
    let ex = artists.iter().position(|a| name_key(&a.g("name").s()) == qk);
    if let Some(i) = ex {
        if i > 0 {
            let a = artists.remove(i);
            artists.insert(0, a);
        }
    }
    let mut best = Value::Null;
    if ym.g("best").g("kind").as_str() == Some("artist") {
        let bid = ym.g("best").g("id");
        if let Some(a) = artists.iter().find(|a| a.g("id") == bid) {
            best = a.clone();
        }
    }
    if best.is_null() && ex.is_some() {
        best = artists[0].clone();
    }
    let mis = ym.g("misspell");
    let misspell = if mis.truthy() && name_key(&mis.s()) != qk { mis.clone() } else { json!("") };
    let mut playlists = ym.g("playlists").arr().to_vec();
    playlists.extend(arr("scLists"));
    json!({
        "best": if best.is_null() { Value::Null } else { json!({ "kind": "artist", "id": best.g("id") }) },
        "misspell": misspell,
        "artists": artists.into_iter().take(20).collect::<Vec<_>>(),
        "tracks": tracks.into_iter().take(80).collect::<Vec<_>>(),
        "albums": ym.g("albums").arr().iter().take(20).cloned().collect::<Vec<_>>(),
        "podcasts": ym.g("podcasts").arr().iter().take(20).cloned().collect::<Vec<_>>(),
        "playlists": playlists.into_iter().take(20).collect::<Vec<_>>(),
        "videos": arr("videos").into_iter().take(20).collect::<Vec<_>>(),
    })
}

/* ---------- short bio from Wikipedia (ru) ---------- */

/// strip «( … )» groups that contain no parentheses (one pass like the JS replace)
fn strip_parens(s: &str) -> String {
    re!(r"\s*\([^()]*\)").replace_all(s, "").into_owned()
}

/// the first sentence (≥ 20 chars) when followed by the end or by a space + capital / digit / quote
pub fn first_sentence_cut(t: &str) -> Option<String> {
    let chars: Vec<(usize, char)> = t.char_indices().collect();
    for (pos, &(i, c)) in chars.iter().enumerate() {
        if pos < 20 {
            continue;
        }
        if !matches!(c, '.' | '!' | '?' | '…') {
            continue;
        }
        let end = i + c.len_utf8();
        let rest = &t[end..];
        if rest.is_empty() {
            return Some(t[..end].to_string());
        }
        let trimmed = rest.trim_start();
        if trimmed.len() < rest.len() {
            if let Some(n) = trimmed.chars().next() {
                if n.is_ascii_uppercase() || ('А'..='Я').contains(&n) || n == 'Ё' || n.is_ascii_digit() || n == '«' || n == '"' {
                    return Some(t[..end].to_string());
                }
            }
        }
    }
    None
}

pub fn clean_bio(text: &str, max: usize) -> String {
    let t = text.replace('\u{0301}', "");
    let t = strip_parens(&strip_parens(&t));
    let t = re!(r"\s+([,.;:])").replace_all(&t, "$1");
    let mut t = re!(r"\s+").replace_all(&t, " ").trim().to_string();
    if t.is_empty() {
        return String::new();
    }
    if let Some(m) = first_sentence_cut(&t) {
        t = m;
    }
    if t.chars().count() > max {
        let s = slice(&t, max - 1);
        t = re!(r"[\s,;:–—-]+\S*$").replacen(&s, 1, "").into_owned() + "…";
    }
    t
}

fn title_key(t: &str) -> String {
    name_key(&re!(r"\s*\([^)]*\)").replace_all(t, ""))
}

fn is_music(s: &str) -> bool {
    re!(r"(?i)(музык|певе|певиц|рэп|исполнител|групп|диджей|продюсер|битмейкер|композитор|коллектив|автор песен)").is_match(s)
}

pub async fn wiki_bio(name: &str, version: &str) -> R<String> {
    let n = name_key(name);
    if n.is_empty() {
        return Ok(String::new());
    }
    let base = "https://ru.wikipedia.org";
    let ua = format!("WaveDesktop/{} (music player)", version);
    let get = |u: String| {
        let ua = ua.clone();
        async move { get_json(&u, Opts::new().timeout(8000).h("Api-User-Agent", &ua)).await }
    };
    let nm = slice(name, 100);
    let s = get(format!(
        "{}/w/api.php?{}",
        base,
        qs(&[("action", "query"), ("list", "search"), ("srsearch", &nm), ("srlimit", "6"), ("format", "json"), ("utf8", "1")])
    ))
    .await?;
    let hits: Vec<Value> = s
        .path(&["query", "search"])
        .arr()
        .iter()
        .filter(|h| h.truthy() && title_key(&h.g("title").s()) == n)
        .take(3)
        .cloned()
        .collect();
    for h in hits {
        let title = h.g("title").s().replace(' ', "_");
        let p = match get(format!("{}/api/rest_v1/page/summary/{}", base, enc(&title))).await {
            Ok(p) => p,
            Err(_) => continue,
        };
        if !p.truthy() || p.g("type").as_str() == Some("disambiguation") || !p.g("extract").truthy() {
            continue;
        }
        let first = clean_bio(&p.g("extract").s(), 400);
        if !is_music(&first) {
            continue;
        }
        return Ok(clean_bio(&p.g("extract").s(), 160));
    }
    Ok(String::new())
}

pub async fn deezer_similar(name: &str, limit: usize) -> R<Vec<Value>> {
    let n = name_key(name);
    let r = get_json(
        &format!("https://api.deezer.com/search/artist?{}", qs(&[("q", name), ("limit", "5")])),
        Opts::new().timeout(8000),
    )
    .await?;
    let a = r.g("data").arr().iter().find(|x| x.truthy() && name_key(&x.g("name").s()) == n).cloned();
    let a = match a {
        Some(a) => a,
        None => return Ok(vec![]),
    };
    let id = a.g("id").n();
    let rel = get_json(
        &format!("https://api.deezer.com/artist/{}/related?limit={}", crate::js::num_str(id), limit),
        Opts::new().timeout(8000),
    )
    .await?;
    Ok(rel
        .g("data")
        .arr()
        .iter()
        .filter(|x| x.truthy() && x.g("name").truthy())
        .map(|x| {
            let pm = x.g("picture_medium").s();
            let avatar = if pm.starts_with("https://") && !pm.contains("/artist//") {
                if x.g("picture_xl").truthy() { x.g("picture_xl").clone() } else { x.g("picture_medium").clone() }
            } else {
                Value::Null
            };
            let fans = x.g("nb_fan").n();
            json!({
                "id": "",
                "name": slice(&x.g("name").sv(), 150),
                "avatar": avatar,
                "followers": crate::js::jn(if fans.is_nan() { 0.0 } else { fans }),
                "source": "deezer",
            })
        })
        .take(limit)
        .collect())
}

/* ---------- wave-recommendations.cjs ---------- */
pub const PLAY_FLOOR: f64 = 100000.0;

pub fn names(t: &Value) -> Vec<String> {
    let mut vals = vec![t.g("artist").s()];
    for a in t.g("artists").arr() {
        vals.push(a.g("name").s());
    }
    let mut out = vec![];
    for s in vals {
        for part in re!(r"(?i)\s*(?:,|;|&|(?-u:\b)feat\.?|(?-u:\b)ft\.?|(?-u:\b)и(?-u:\b))\s*").split(&s) {
            let k = name_key(part);
            if !k.is_empty() && k != "soundcloud" && k != "audius" && k != "неизвестныйисполнитель" {
                out.push(k);
            }
        }
    }
    out
}

pub fn known_set(tracks: &[Value], artists: &[Value]) -> HashSet<String> {
    let mut s: HashSet<String> = tracks.iter().flat_map(names).collect();
    for a in artists {
        let k = if a.g("name").truthy() { name_key(&a.g("name").s()) } else { name_key(&a.s()) };
        if !k.is_empty() {
            s.insert(k);
        }
    }
    s
}

pub fn relevant(t: &Value, known: &HashSet<String>) -> bool {
    let p = t.g("plays").n();
    names(t).iter().any(|n| known.contains(n)) || (p.is_finite() && p >= PLAY_FLOOR)
}

pub fn obj_of(pairs: Vec<(&str, Value)>) -> Value {
    let mut m = Map::new();
    for (k, v) in pairs {
        m.insert(k.to_string(), v);
    }
    Value::Object(m)
}
