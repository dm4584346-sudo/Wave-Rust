//! Audius: open, decentralised music API. Free, no key, full-length streams (MP3 320).

use super::soundcloud::{day_of, or0, or_null};
use crate::http::{get_json, Opts};
use crate::js::{enc, J, E, R};
use crate::re;
use serde_json::{json, Map, Value};

const HOST: &str = "https://api.audius.co";
fn q(p: &str) -> String {
    format!("{}/v1{}{}app_name=WaveDesktop", HOST, p, if p.contains('?') { "&" } else { "?" })
}

fn undef(v: &Value) -> String {
    if v.is_null() {
        "undefined".into()
    } else {
        v.sv()
    }
}

fn track(t: &Value) -> Value {
    let mut o = Map::new();
    o.insert("id".into(), json!(format!("au:{}", undef(t.g("id")))));
    o.insert("source".into(), json!("audius"));
    o.insert("title".into(), t.g("title").clone());
    let un = t.path(&["user", "name"]);
    o.insert("artist".into(), if un.truthy() { un.clone() } else { json!("Audius") });
    o.insert("artists".into(), json!([{ "id": format!("au:{}", undef(t.path(&["user", "id"]))), "name": un }]));
    o.insert("duration".into(), or0(t.g("duration")));
    let a = t.path(&["artwork", "480x480"]);
    o.insert("cover".into(), if a.truthy() { a.clone() } else { or_null(t.path(&["artwork", "1000x1000"])) });
    o.insert("link".into(), json!(format!("https://audius.co{}", t.g("permalink").s())));
    o.insert("genre".into(), json!(t.g("genre").s()));
    o.insert("plays".into(), or0(t.g("play_count")));
    let rd = if t.g("release_date").truthy() { t.g("release_date") } else { t.g("created_at") };
    if let Some(d) = day_of(rd) {
        o.insert("released".into(), json!(d));
    }
    o.insert("preview".into(), json!(false));
    o.insert("streamable".into(), json!(t.g("is_streamable") != &Value::Bool(false)));
    o.insert("q".into(), json!("hq"));
    Value::Object(o)
}
fn list(d: &Value) -> Vec<Value> {
    d.arr().iter().map(track).filter(|t| t.g("streamable").truthy()).collect()
}
fn sid(id: &str) -> R<String> {
    let s = id.strip_prefix("au:").unwrap_or(id).to_string();
    if !re!(r"^[A-Za-z0-9]+$").is_match(&s) {
        return Err(E::new("Неверный id Audius"));
    }
    Ok(s)
}

pub async fn search(text: &str, limit: usize) -> R<Vec<Value>> {
    Ok(list(get_json(&q(&format!("/tracks/search?query={}&limit={}", enc(text), limit)), Opts::new()).await?.g("data")))
}
pub async fn search_users(text: &str, limit: usize) -> R<Vec<Value>> {
    let r = get_json(&q(&format!("/users/search?query={}&limit={}", enc(text), limit)), Opts::new()).await?;
    Ok(r.g("data")
        .arr()
        .iter()
        .map(|x| {
            json!({
                "id": format!("au:{}", undef(x.g("id"))),
                "source": "audius",
                "name": x.g("name"),
                "avatar": or_null(x.path(&["profile_picture", "480x480"])),
                "followers": or0(x.g("follower_count")),
                "link": format!("https://audius.co/{}", undef(x.g("handle"))),
            })
        })
        .collect())
}
pub async fn trending() -> R<Vec<Value>> {
    Ok(list(get_json(&q("/tracks/trending"), Opts::new()).await?.g("data")).into_iter().take(30).collect())
}
pub async fn user(id: &str) -> R<Value> {
    let r = get_json(&q(&format!("/users/{}", sid(id)?)), Opts::new()).await?;
    let x = r.g("data");
    Ok(json!({
        "id": format!("au:{}", undef(x.g("id"))),
        "source": "audius",
        "name": x.g("name"),
        "avatar": or_null(x.path(&["profile_picture", "480x480"])),
    }))
}
pub async fn artist(id: &str) -> R<Value> {
    let s = sid(id)?;
    let (u, t) = tokio::join!(
        async { get_json(&q(&format!("/users/{}", s)), Opts::new()).await },
        async { get_json(&q(&format!("/users/{}/tracks?limit=50", s)), Opts::new()).await }
    );
    let u = u?;
    let t = t?;
    let x = u.g("data");
    let b = x.path(&["cover_photo", "2000x"]);
    Ok(json!({
        "artist": {
            "id": format!("au:{}", undef(x.g("id"))),
            "source": "audius",
            "name": x.g("name"),
            "avatar": or_null(x.path(&["profile_picture", "480x480"])),
            "banner": if b.truthy() { b.clone() } else { or_null(x.path(&["cover_photo", "640x"])) },
            "followers": or0(x.g("follower_count")),
            "tracks": or0(x.g("track_count")),
            "description": x.g("bio").s(),
            "link": format!("https://audius.co/{}", undef(x.g("handle"))),
        },
        "top": [],
        "tracks": list(t.g("data")),
    }))
}
pub async fn artist_tracks(id: &str) -> R<Value> {
    let s = sid(id)?;
    let (r, all) = tokio::join!(artist(id), async { get_json(&q(&format!("/users/{}/tracks?limit=100&sort=plays", s)), Opts::new()).await });
    let r = r.ok();
    let all = all.ok();
    let mut tracks = match all.as_ref().map(|a| a.g("data")).filter(|d| d.truthy()) {
        Some(d) => list(d),
        None => r.as_ref().map(|r| r.g("tracks").arr().to_vec()).unwrap_or_default(),
    };
    tracks.sort_by(|a, b| b.g("plays").n().partial_cmp(&a.g("plays").n()).unwrap_or(std::cmp::Ordering::Equal));
    let artist = r
        .as_ref()
        .map(|r| r.g("artist").clone())
        .filter(|a| a.truthy())
        .unwrap_or(json!({ "id": format!("au:{}", s), "source": "audius", "name": "" }));
    let total = tracks.len();
    Ok(json!({ "artist": artist, "tracks": tracks, "total": total }))
}
pub async fn stream(id: &str) -> R<Value> {
    let r = get_json(&q(&format!("/tracks/{}/stream?no_redirect=true", sid(id)?)), Opts::new()).await?;
    if !r.g("data").truthy() {
        return Err(E::new("Поток Audius недоступен"));
    }
    Ok(json!({ "url": r.g("data"), "type": "file", "preview": false, "q": { "codec": "MP3", "kbps": 320, "src": "Audius" } }))
}
