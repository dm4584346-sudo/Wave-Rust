//! Spotify Web API (own Client ID, PKCE). Spotify gives no raw audio to third-party apps, so it is a LIBRARY /
//! CATALOG source; the audio is matched on SoundCloud / Audius. Also the public embed import without login.

use crate::app::{app, p, setting};
use crate::http::{get_json, Opts};
use crate::js::{enc, jn, now_ms, qs, round, slice, J, E, R};
use crate::re;
use base64::Engine;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::sync::Mutex;

pub const REDIRECT: &str = "http://127.0.0.1:43821/callback";
const SCOPES: &str =
    "user-library-read playlist-read-private playlist-read-collaborative user-read-private user-top-read";

fn b64(b: &[u8]) -> String {
    base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(b)
}

pub struct Pkce {
    pub verifier: String,
    pub challenge: String,
    pub state: String,
}
pub fn pkce() -> Pkce {
    let mut v = [0u8; 48];
    rand::RngCore::fill_bytes(&mut rand::thread_rng(), &mut v);
    let verifier = b64(&v);
    let challenge = b64(&Sha256::digest(verifier.as_bytes()));
    let st: [u8; 16] = rand::random();
    Pkce { verifier, challenge, state: b64(&st) }
}
pub fn auth_url(client_id: &str, p: &Pkce) -> String {
    format!(
        "https://accounts.spotify.com/authorize?{}",
        qs(&[
            ("client_id", client_id),
            ("response_type", "code"),
            ("redirect_uri", REDIRECT),
            ("code_challenge_method", "S256"),
            ("code_challenge", &p.challenge),
            ("state", &p.state),
            ("scope", SCOPES),
        ])
    )
}
async fn token_request(fields: &[(&str, &str)]) -> R<Value> {
    get_json(
        "https://accounts.spotify.com/api/token",
        Opts::new().h("Content-Type", "application/x-www-form-urlencoded").post(qs(fields)),
    )
    .await
}
pub async fn exchange(client_id: &str, code: &str, verifier: &str) -> R<Value> {
    token_request(&[
        ("grant_type", "authorization_code"),
        ("code", code),
        ("redirect_uri", REDIRECT),
        ("client_id", client_id),
        ("code_verifier", verifier),
    ])
    .await
}
async fn refresh(client_id: &str, rt: &str) -> R<Value> {
    token_request(&[("grant_type", "refresh_token"), ("refresh_token", rt), ("client_id", client_id)]).await
}

/* ---------- the session (refresh token kept encrypted in spotify-session.bin) ---------- */
pub struct Session {
    pub token: Option<String>,
    pub refresh: Option<String>,
    pub expires: f64,
    pub me: Value,
}
pub static SESSION: Mutex<Session> = Mutex::new(Session { token: None, refresh: None, expires: 0.0, me: Value::Null });

fn vault() -> std::path::PathBuf {
    p("spotify-session.bin")
}
pub fn save() {
    let r = SESSION.lock().unwrap().refresh.clone();
    if let Some(b) = crate::vault::encrypt(&app().data, &json!({ "refresh": r }).to_string()) {
        let _ = std::fs::write(vault(), b);
    }
}
pub fn load() {
    if let Ok(b) = std::fs::read(vault()) {
        if let Some(s) = crate::vault::decrypt(&app().data, &b) {
            if let Ok(v) = serde_json::from_str::<Value>(&s) {
                let r = v.g("refresh");
                SESSION.lock().unwrap().refresh = if r.truthy() { Some(r.s()) } else { None };
            }
        }
    }
}
pub fn logout() {
    *SESSION.lock().unwrap() = Session { token: None, refresh: None, expires: 0.0, me: Value::Null };
    let _ = std::fs::remove_file(vault());
}
pub fn connected() -> bool {
    SESSION.lock().unwrap().refresh.is_some()
}
pub fn set_login(r: &Value) {
    let mut s = SESSION.lock().unwrap();
    *s = Session {
        token: Some(r.g("access_token").s()),
        refresh: if r.g("refresh_token").truthy() { Some(r.g("refresh_token").s()) } else { None },
        expires: now_ms() + r.g("expires_in").n() * 1000.0,
        me: Value::Null,
    };
}
pub fn set_me(me: Value) {
    SESSION.lock().unwrap().me = me;
}
pub fn public() -> Value {
    let s = SESSION.lock().unwrap();
    let n = s.me.g("display_name");
    let pr = s.me.g("product");
    json!({
        "connected": s.refresh.is_some(),
        "name": if n.truthy() { n.clone() } else { Value::Null },
        "product": if pr.truthy() { pr.clone() } else { Value::Null },
    })
}

pub async fn token() -> R<String> {
    let rt = {
        let s = SESSION.lock().unwrap();
        if let Some(t) = &s.token {
            if s.expires > now_ms() + 30000.0 {
                return Ok(t.clone());
            }
        }
        s.refresh.clone()
    };
    let cid = setting("spotifyClientId").s();
    let rt = match rt {
        Some(r) if !cid.is_empty() => r,
        _ => return Err(E::new("Подключите Spotify в настройках")),
    };
    let r = refresh(&cid, &rt).await?;
    let new_rt = r.g("refresh_token");
    {
        let mut s = SESSION.lock().unwrap();
        s.token = Some(r.g("access_token").s());
        s.expires = now_ms() + r.g("expires_in").n() * 1000.0;
        if new_rt.truthy() {
            s.refresh = Some(new_rt.s());
        }
    }
    if new_rt.truthy() {
        save();
    }
    let t = SESSION.lock().unwrap().token.clone().unwrap_or_default();
    Ok(t)
}

pub fn track(t: &Value) -> Option<Value> {
    if !t.truthy() || !t.g("id").truthy() || (t.g("type").truthy() && t.g("type").as_str() != Some("track")) {
        return None;
    }
    let artists = t.g("artists").arr();
    let img = t.path(&["album", "images", "0", "url"]);
    let link = t.path(&["external_urls", "spotify"]);
    Some(json!({
        "id": format!("sp:{}", t.g("id").sv()),
        "source": "spotify",
        "title": t.g("name"),
        "artist": artists.iter().map(|a| a.g("name").s()).collect::<Vec<_>>().join(", "),
        "artists": artists.iter().map(|a| json!({ "id": format!("sp:{}", a.g("id").sv()), "name": a.g("name") })).collect::<Vec<_>>(),
        "duration": jn(round(t.g("duration_ms").n().max(0.0) / 1000.0)),
        "cover": if img.truthy() { img.clone() } else { Value::Null },
        "link": if link.truthy() { link.clone() } else { json!("") },
        "explicit": t.g("explicit").truthy(),
        "preview": false,
        "streamable": true,
    }))
}

async fn api(path: &str) -> R<Value> {
    let url = if path.starts_with("http") { path.to_string() } else { format!("https://api.spotify.com/v1{}", path) };
    let tok = token().await?;
    get_json(&url, Opts::new().h("Authorization", &format!("Bearer {}", tok))).await
}

async fn pages(path: &str, max: usize) -> R<Vec<Value>> {
    let mut out = vec![];
    let mut visited = HashSet::new();
    let mut next = Some(path.to_string());
    while let Some(n) = next {
        if !visited.insert(n.clone()) {
            return Err(E::new("Spotify повторил страницу списка — попробуйте позже"));
        }
        if re!(r"(?i)^https?:").is_match(&n) && !re!(r"(?i)^https://api\.spotify\.com/v1/").is_match(&n) {
            return Err(E::new("Неверный адрес страницы Spotify"));
        }
        let r = api(&n).await?;
        out.extend(r.g("items").arr().iter().cloned());
        let nx = r.g("next");
        if out.len() > max || (out.len() >= max && nx.truthy()) {
            return Err(E::new("Список Spotify слишком большой для одного импорта"));
        }
        next = nx.as_str().filter(|s| !s.is_empty()).map(String::from);
    }
    Ok(out)
}

pub async fn me() -> R<Value> {
    api("/me").await
}
pub async fn liked() -> R<Vec<Value>> {
    Ok(pages("/me/tracks?limit=50", 50000)
        .await?
        .iter()
        .filter_map(|x| track(if x.g("track").truthy() { x.g("track") } else { x.g("item") }))
        .collect())
}
pub async fn playlists() -> R<Vec<Value>> {
    Ok(pages("/me/playlists?limit=50", 500)
        .await?
        .iter()
        .filter(|p| p.truthy())
        .map(|p| {
            let c = if !p.path(&["items", "total"]).is_null() {
                p.path(&["items", "total"]).clone()
            } else if !p.path(&["tracks", "total"]).is_null() {
                p.path(&["tracks", "total"]).clone()
            } else {
                json!(0)
            };
            let img = p.path(&["images", "0", "url"]);
            json!({
                "id": format!("spp:{}", p.g("id").sv()),
                "source": "spotify",
                "title": p.g("name"),
                "owner": p.path(&["owner", "display_name"]).s(),
                "count": c,
                "cover": if img.truthy() { img.clone() } else { Value::Null },
            })
        })
        .collect())
}
pub async fn playlist(id: &str) -> R<Vec<Value>> {
    let s = id.strip_prefix("spp:").unwrap_or(id);
    if !re!(r"^[A-Za-z0-9]+$").is_match(s) {
        return Err(E::new("Неверный плейлист"));
    }
    let items = match pages(&format!("/playlists/{}/items?limit=50", s), 50000).await {
        Ok(i) => i,
        Err(e) if e.status == Some(404) => pages(&format!("/playlists/{}/tracks?limit=50", s), 50000).await?,
        Err(e) => return Err(e),
    };
    Ok(items
        .iter()
        .filter_map(|x| track(if x.g("item").truthy() { x.g("item") } else { x.g("track") }))
        .collect())
}
pub async fn search(q: &str) -> R<Vec<Value>> {
    let r = api(&format!("/search?type=track&limit=10&q={}", enc(q))).await?;
    Ok(r.path(&["tracks", "items"]).arr().iter().filter_map(track).collect())
}
pub async fn top() -> R<Vec<Value>> {
    let r = api("/me/top/tracks?limit=30&time_range=short_term").await?;
    Ok(r.g("items").arr().iter().filter_map(track).collect())
}
pub async fn recent_liked() -> R<Vec<Value>> {
    let r = api("/me/tracks?limit=50").await?;
    Ok(r.g("items").arr().iter().filter_map(|x| track(x.g("track"))).collect())
}
pub async fn artist_stats(name: &str) -> R<Value> {
    let r = api(&format!("/search?type=artist&limit=5&q={}", enc(&slice(name, 100)))).await?;
    let list = r.path(&["artists", "items"]).arr();
    let low = |s: &str| s.to_lowercase().trim().to_string();
    let a = list.iter().find(|x| low(&x.g("name").s()) == low(name)).or(list.first());
    Ok(match a {
        Some(a) => {
            let l = a.path(&["external_urls", "spotify"]);
            let c = a.path(&["images", "0", "url"]);
            let f = a.path(&["followers", "total"]);
            json!({
                "name": a.g("name"),
                "followers": if f.truthy() { f.clone() } else { json!(0) },
                "link": if l.truthy() { l.clone() } else { Value::Null },
                "cover": if c.truthy() { c.clone() } else { Value::Null },
            })
        }
        None => Value::Null,
    })
}

/* ---------- public import without login: open.spotify.com/embed pages carry the list as JSON ---------- */
pub fn parse_url(raw: &str) -> Option<(String, String)> {
    let u = url::Url::parse(raw).ok()?;
    let h = u.host_str()?;
    if h != "open.spotify.com" && h != "play.spotify.com" {
        return None;
    }
    let m = re!(r"/(playlist|album|track)/([A-Za-z0-9]{10,40})").captures(u.path())?;
    Some((m[1].to_string(), m[2].to_string()))
}

pub async fn embed(raw: &str) -> R<Value> {
    let (ty, id) = parse_url(raw).ok_or_else(|| E::new("Не распознал ссылку Spotify"))?;
    let (st, _, html) = crate::http::text(
        &format!("https://open.spotify.com/embed/{}/{}", ty, id),
        Opts::new().h("User-Agent", crate::http::UA).h("Accept-Language", "ru,en").timeout(20000),
    )
    .await?;
    if !(200..300).contains(&st) {
        return Err(E::new(if st == 404 {
            "Плейлист Spotify не найден или закрыт".to_string()
        } else {
            format!("Spotify ответил {}", st)
        }));
    }
    let m = re!(r#"(?s)<script id="__NEXT_DATA__" type="application/json">(.*?)</script>"#)
        .captures(&html)
        .ok_or_else(|| E::new("Spotify изменил страницу — подключите аккаунт Spotify для импорта"))?;
    let data = crate::http::parse_json(&m[1])?;
    let e = data.path(&["props", "pageProps", "state", "data", "entity"]);
    if !e.truthy() {
        return Err(E::new("Пустой ответ Spotify"));
    }
    let pc = e.path(&["coverArt", "sources", "0", "url"]);
    let pc = if pc.truthy() { pc.clone() } else { Value::Null };
    let mk = |x: &Value| -> Option<Value> {
        let uri = x.g("uri").s();
        let id = uri.rsplit(':').next().unwrap_or("").to_string();
        if !re!(r"^[A-Za-z0-9]+$").is_match(&id) {
            return None;
        }
        let artist = if x.g("subtitle").truthy() {
            x.g("subtitle").s()
        } else {
            x.g("artists").arr().iter().map(|a| a.g("name").s()).collect::<Vec<_>>().join(", ")
        };
        let artists: Vec<Value> = re!(r",\s*").split(&artist).map(|n| json!({ "id": null, "name": n })).collect();
        Some(json!({
            "id": format!("sp:{}", id),
            "source": "spotify",
            "title": if x.g("title").truthy() { x.g("title").clone() } else { x.g("name").clone() },
            "artist": artist,
            "artists": artists,
            "duration": jn(round(x.g("duration").n().max(0.0) / 1000.0)),
            "cover": if ty == "album" { pc.clone() } else { Value::Null },
            "link": format!("https://open.spotify.com/track/{}", id),
            "explicit": x.g("isExplicit").truthy(),
            "preview": false,
            "streamable": true,
        }))
    };
    let list: Vec<Value> = if ty == "track" { mk(e).into_iter().collect() } else { e.g("trackList").arr().iter().filter_map(mk).collect() };
    let title = if e.g("title").truthy() {
        e.g("title").clone()
    } else if e.g("name").truthy() {
        e.g("name").clone()
    } else {
        json!("Spotify")
    };
    Ok(json!({ "id": id, "type": ty, "title": title, "cover": pc, "tracks": list }))
}
