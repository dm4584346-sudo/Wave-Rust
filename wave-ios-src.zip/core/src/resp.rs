//! A transport-neutral HTTP answer of the media handlers (own files, decrypted Yandex streams, the proxy).

use bytes::Bytes;
use futures_util::Stream;
use std::pin::Pin;

pub type ByteStream = Pin<Box<dyn Stream<Item = Result<Bytes, std::io::Error>> + Send>>;

pub enum Body {
    Empty,
    Bytes(Bytes),
    Stream(ByteStream),
}

pub struct Resp {
    pub status: u16,
    pub headers: Vec<(String, String)>,
    pub body: Body,
}

impl Resp {
    pub fn text(status: u16, t: &str) -> Resp {
        Resp {
            status,
            headers: vec![("Content-Type".into(), "text/plain;charset=UTF-8".into())],
            body: Body::Bytes(Bytes::from(t.to_string())),
        }
    }
    pub fn empty(status: u16) -> Resp {
        Resp { status, headers: vec![], body: Body::Empty }
    }
    pub fn h(mut self, k: &str, v: &str) -> Resp {
        self.headers.push((k.to_string(), v.to_string()));
        self
    }
}

/// a channel-fed body: the producer task stops as soon as the receiver (the client) is gone
pub fn channel(cap: usize) -> (tokio::sync::mpsc::Sender<Result<Bytes, std::io::Error>>, ByteStream) {
    let (tx, rx) = tokio::sync::mpsc::channel(cap);
    let s = futures_util::stream::unfold(rx, |mut rx| async move { rx.recv().await.map(|x| (x, rx)) });
    (tx, Box::pin(s))
}
