//! Sign-in windows (Яндекс, Spotify). On the phone such a window is the sign-in screen of the Android app: it opens
//! with a «window-open» request, every address it goes to comes back through POST /api/window (or the Spotify
//! callback port) and closing it ends the sign-in.

use crate::app::native;
use serde_json::json;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;
use tokio::sync::mpsc::{unbounded_channel, UnboundedReceiver, UnboundedSender};

pub enum Ev {
    Nav(String),
    Closed,
}

static WINDOWS: Mutex<Vec<(String, UnboundedSender<Ev>)>> = Mutex::new(Vec::new());
static SEQ: AtomicU64 = AtomicU64::new(0);

/// a new visible window that loads `url`
pub fn open(url: &str) -> (String, UnboundedReceiver<Ev>) {
    let id = (SEQ.fetch_add(1, Ordering::SeqCst) + 1).to_string();
    let (tx, rx) = unbounded_channel();
    WINDOWS.lock().unwrap().push((id.clone(), tx));
    native(json!({ "type": "window-open", "id": id, "url": url }));
    (id, rx)
}

/// `win.close()`: the phone closes its sign-in screen, the waiting flow gets «closed»
pub fn close(id: &str) {
    let w = {
        let mut ws = WINDOWS.lock().unwrap();
        ws.iter().position(|x| x.0 == id).map(|i| ws.remove(i))
    };
    if let Some((_, tx)) = w {
        native(json!({ "type": "window-close", "id": id }));
        let _ = tx.send(Ev::Closed);
    }
}

/// an address the sign-in screen went to
pub fn nav(id: &str, url: &str) {
    if let Some((_, tx)) = WINDOWS.lock().unwrap().iter().find(|x| x.0 == id) {
        let _ = tx.send(Ev::Nav(url.to_string()));
    }
}

/// the newest sign-in window (only one sign-in runs at a time)
pub fn newest() -> Option<String> {
    WINDOWS.lock().unwrap().last().map(|x| x.0.clone())
}
